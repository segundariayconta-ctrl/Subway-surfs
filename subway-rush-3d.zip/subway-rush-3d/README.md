# SUBWAY RUSH 3D

Jogo autoral de corrida infinita em HTML5, CSS3, JavaScript e Three.js. Os personagens, trilhos, prédios, trens, obstáculos, moedas e power-ups são montados com geometrias criadas por código, sem depender de imagens externas.

## Como executar

1. Extraia a pasta `subway-rush-3d`.
2. É necessário ter conexão com a internet para carregar a biblioteca Three.js pelo CDN na primeira inicialização.
3. Abra um terminal dentro da pasta e execute:

   **Windows:**
   ```bash
   py -m http.server 8000
   ```
   **Linux / macOS:**
   ```bash
   python3 -m http.server 8000
   ```

4. No navegador, acesse `http://localhost:8000`.
5. No Android, para testar no próprio aparelho, coloque a pasta em um servidor HTTP acessível pelo celular ou use um editor/servidor local que sirva arquivos HTML. Abrir o arquivo diretamente como `file://` não é recomendado por causa dos módulos do navegador.

## Controles

- **Computador:** `A` / `D` ou setas para mudar de faixa; `Espaço` / `W` / seta para cima para pular; `S` / seta para baixo para deslizar; `P` ou `Esc` para pausar.
- **Celular:** deslize para esquerda/direita/cima/baixo sobre a cena ou use os botões que aparecem durante a corrida.
- **Interface:** os botões de menu, loja, skins, missões, opções, pausa, reinício e recompensa diária são funcionais.

## O que está incluído

- Corrida em três faixas com cenário procedural reciclado.
- Barreiras, placas, trens e obstáculos suspensos com colisões.
- Personagem 3D animado, pulo, deslize, skins selecionáveis e desbloqueáveis.
- Moedas, ímã, super tênis, jetpack, hoverboard e multiplicador de score.
- Loja de melhorias e recompensa diária simulada.
- Missões com progresso e resgate de recompensa.
- Recorde, moedas, skins, melhorias e preferências salvos com `localStorage`.
- Efeitos sonoros e música sintetizados via Web Audio, controle de volume e qualidade gráfica.

## Notas técnicas

- O projeto usa Three.js `0.160.0` a partir de jsDelivr; a conexão com a internet é necessária para carregar essa dependência.
- O jogo gera modelos e materiais em tempo real e adapta o pixel ratio para tentar manter o desempenho em celulares.
- Progresso salvo no navegador pode ser apagado se os dados do site forem limpos.
