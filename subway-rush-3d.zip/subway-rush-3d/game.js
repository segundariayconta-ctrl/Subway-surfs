/* SUBWAY RUSH 3D — jogo autoral feito com geometria procedural e Three.js */
(async function () {
  const loadingDetail = document.getElementById('loading-detail');
  try {
    loadingDetail.textContent = 'Carregando biblioteca 3D...';
    const THREE = await import('https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.module.js');
    boot(THREE);
  } catch (err) {
    document.getElementById('loading').classList.add('hidden');
    document.getElementById('error-screen').classList.remove('hidden');
    document.getElementById('error-detail').textContent = String(err && err.message ? err.message : err);
  }
})();

function boot(THREE) {
  const $ = (id) => document.getElementById(id);
  const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
  const rand = (min, max) => min + Math.random() * (max - min);
  const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
  const LANES = [-2.25, 0, 2.25];
  const SEGMENT_LENGTH = 16;
  const SEGMENT_COUNT = 9;
  const SAVE_KEY = 'subwayRush3D.save.v1';

  const SKINS = [
    { id:'street', name:'Street Nova', desc:'O primeiro corredor. Rápido e estiloso.', price:0, color:'#39d6d0', pants:'#18273c', accent:'#f8f8ff', icon:'🧢', title:'URBAN STARTER' },
    { id:'pulse', name:'Neon Pulse', desc:'Jaqueta elétrica com detalhes neon.', price:180, color:'#fa4fbd', pants:'#191b35', accent:'#67fff0', icon:'🧥', title:'NEON SERIES' },
    { id:'chrome', name:'Chrome Runner', desc:'Visual metálico direto do futuro.', price:320, color:'#b7d0e6', pants:'#34465a', accent:'#48e6fa', icon:'🤖', title:'CYBER SERIES' },
    { id:'gold', name:'Gold Phantom', desc:'Brilho dourado de quem domina a pista.', price:520, color:'#ffc94f', pants:'#44311b', accent:'#fff1b1', icon:'👑', title:'ELITE SERIES' },
    { id:'volt', name:'Robo Volt', desc:'Armadura robótica com energia azul.', price:430, color:'#6d8cff', pants:'#172744', accent:'#76fff1', icon:'⚡', title:'TECH SERIES' },
    { id:'ember', name:'Ember Rush', desc:'Jaqueta quente e tênis de fogo.', price:260, color:'#ff725e', pants:'#31202b', accent:'#ffd36e', icon:'🔥', title:'STREET SERIES' }
  ];
  const SHOP_ITEMS = [
    { id:'magnet', name:'Ímã ampliado', icon:'🧲', desc:'Aumenta em 2 s a duração do ímã por nível.', price:160, max:3 },
    { id:'shoes', name:'Super tênis', icon:'👟', desc:'Melhora a altura do salto durante a corrida.', price:190, max:3 },
    { id:'multiplier', name:'Bônus de score', icon:'✦', desc:'Aumenta em 1,5 s o multiplicador por nível.', price:220, max:3 },
    { id:'board', name:'Prancha reforçada', icon:'🛹', desc:'Aumenta em 2 s a duração do hoverboard.', price:250, max:3 }
  ];
  const MISSIONS = [
    { id:'coins30', icon:'🟡', title:'Caçador de moedas', desc:'Colete 30 moedas ao longo das corridas.', target:30, metric:'coins', reward:120 },
    { id:'distance1200', icon:'🏁', title:'Pernas incansáveis', desc:'Corra 1.200 metros no total.', target:1200, metric:'distance', reward:180 },
    { id:'powers3', icon:'⚡', title:'Energia extra', desc:'Ative 3 power-ups durante suas corridas.', target:3, metric:'powers', reward:140 },
    { id:'score1000', icon:'🏆', title:'Na liderança', desc:'Alcance 1.000 pontos em uma única corrida.', target:1000, metric:'bestRun', reward:200 }
  ];

  function freshSave() {
    return { coins:0, best:0, equipped:'street', unlocked:['street'], upgrades:{magnet:0,shoes:0,multiplier:0,board:0}, claimed:[], lastDaily:'', stats:{coins:0,distance:0,powers:0,bestRun:0,runs:0}, settings:{quality:'high',weather:true,audio:true,vibration:true,volume:45} };
  }
  function loadSave() {
    try {
      const raw = localStorage.getItem(SAVE_KEY);
      if (!raw) return freshSave();
      const parsed = JSON.parse(raw);
      const base = freshSave();
      return { ...base, ...parsed,
        upgrades:{...base.upgrades,...(parsed.upgrades||{})},
        stats:{...base.stats,...(parsed.stats||{})},
        settings:{...base.settings,...(parsed.settings||{})},
        unlocked:Array.isArray(parsed.unlocked)?parsed.unlocked:['street'],
        claimed:Array.isArray(parsed.claimed)?parsed.claimed:[]
      };
    } catch { return freshSave(); }
  }
  let save = loadSave();
  if (!save.unlocked.includes('street')) save.unlocked.unshift('street');
  if (!SKINS.some(s=>s.id===save.equipped && save.unlocked.includes(s.id))) save.equipped='street';
  function persist() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch {} }

  const canvas = $('game-canvas');
  let renderer, scene, camera, clock;
  let playerRoot, playerParts = {}, playerMaterials = {};
  let segments = [], entities = [], particles = [];
  let boardMesh, jetPackMesh, magnetRing;
  let state = 'menu'; // menu, running, paused, gameover
  let activeScreen = 'menu-screen';
  let laneIndex = 1, laneX = 0, jumpY = 0, jumpVelocity = 0, slideTimer = 0, runDistance = 0, score = 0, runCoins = 0;
  let spawnTimer = 0.4, powerTimer = 5.5, elapsed = 0, cameraShake = 0, newRecord = false;
  let activePowers = { magnet:0, shoes:0, jetpack:0, hoverboard:0, multiplier:0 };
  let hoverShieldUsed = false;
  let toastTimer = null, lastHudScore = -1, lastHudCoins = -1;
  let audioCtx = null, masterGain = null, musicTimer = null, musicStep = 0;
  let screenBeforePause = 'menu-screen';

  initScene();
  buildCharacter(save.equipped);
  setupUI();
  updateAllUI();
  persist();
  $('loading').classList.add('done');
  setTimeout(() => $('loading').classList.add('hidden'), 450);
  clock = new THREE.Clock();
  renderer.setAnimationLoop(animate);

  function mat(color, roughness=0.72, metalness=0.05, extra={}) {
    return new THREE.MeshStandardMaterial({ color, roughness, metalness, ...extra });
  }
  function box(w,h,d, material, x=0,y=0,z=0) {
    const mesh = new THREE.Mesh(new THREE.BoxGeometry(w,h,d), material);
    mesh.position.set(x,y,z); mesh.castShadow = true; mesh.receiveShadow = true; return mesh;
  }
  function addGlow(parent, x,y,z, color, size=0.11) {
    const glow = new THREE.Mesh(new THREE.SphereGeometry(size, 8, 6), new THREE.MeshBasicMaterial({color}));
    glow.position.set(x,y,z); parent.add(glow); return glow;
  }

  function initScene() {
    scene = new THREE.Scene();
    scene.background = new THREE.Color(0x0b1930);
    scene.fog = new THREE.FogExp2(0x0b1930, 0.010);
    camera = new THREE.PerspectiveCamera(64, window.innerWidth/window.innerHeight, 0.1, 240);
    camera.position.set(-1.9, 4.5, 10.5); camera.lookAt(-1.9, 1.2, -8);
    renderer = new THREE.WebGLRenderer({ canvas, antialias:true, alpha:false, powerPreference:'high-performance' });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1, save.settings.quality==='high'?1.65:1.15));
    renderer.setSize(window.innerWidth, window.innerHeight, false);
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    renderer.shadowMap.enabled = save.settings.quality === 'high';
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    scene.add(new THREE.HemisphereLight(0xa7d5ff, 0x111521, 1.5));
    const moonLight = new THREE.DirectionalLight(0xc2e1ff, 2.25);
    moonLight.position.set(-8, 18, 10); moonLight.castShadow = true;
    moonLight.shadow.mapSize.set(1024,1024);
    moonLight.shadow.camera.left=-18; moonLight.shadow.camera.right=18; moonLight.shadow.camera.top=22; moonLight.shadow.camera.bottom=-15;
    scene.add(moonLight);
    const cyanLight = new THREE.PointLight(0x39e9e1, 4, 28, 2); cyanLight.position.set(5,5,-8); scene.add(cyanLight);
    const pinkLight = new THREE.PointLight(0x9c54ff, 3, 28, 2); pinkLight.position.set(-7,4,-20); scene.add(pinkLight);
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(300,300), mat(0x08111d,0.98));
    ground.rotation.x=-Math.PI/2; ground.position.y=-0.58; ground.position.z=-80; ground.receiveShadow=true; scene.add(ground);
    createSkylineSegments();
    createPlayerRoot();
    window.addEventListener('resize', onResize);
    document.addEventListener('visibilitychange', () => { if (document.hidden && state === 'running') pauseGame(); });
  }

  function createSkylineSegments() {
    const floorMat=mat(0x303a4a,0.9), railMat=mat(0x778694,0.35,0.8), railDark=mat(0x171f2d,0.76,0.25), tieMat=mat(0x555f6b,0.92), buildingMats=[mat(0x14243b),mat(0x1b2b42),mat(0x172033),mat(0x24334a)], windowMat=new THREE.MeshBasicMaterial({color:0x4bbdc5}), amberMat=new THREE.MeshBasicMaterial({color:0xffc86c});
    for(let i=0;i<SEGMENT_COUNT;i++) {
      const g=new THREE.Group(); g.position.z=-i*SEGMENT_LENGTH;
      const floor=box(13.5,0.42,SEGMENT_LENGTH,floorMat,0,-0.46,0); g.add(floor);
      // Três faixas de trilhos, com dormentes repetidos.
      for(const lane of LANES) {
        for(let k=0;k<4;k++) g.add(box(1.72,0.12,0.32,tieMat,lane,-0.20,-6+k*4));
        g.add(box(0.12,0.18,SEGMENT_LENGTH,railMat,lane-0.62,-0.13,0));
        g.add(box(0.12,0.18,SEGMENT_LENGTH,railMat,lane+0.62,-0.13,0));
        g.add(box(0.16,0.04,SEGMENT_LENGTH,railDark,lane,-0.20,0));
      }
      // Bordas iluminadas das plataformas.
      g.add(box(0.09,0.08,SEGMENT_LENGTH,windowMat,-6.45,-0.19,0));
      g.add(box(0.09,0.08,SEGMENT_LENGTH,windowMat,6.45,-0.19,0));
      for(const side of [-1,1]) {
        for(let b=0;b<2;b++) {
          const x=side*(9.1+b*4.3), h=rand(8,18), w=rand(3.1,4.1), d=rand(5,8), bz=rand(-4,4);
          const building=box(w,h,d,pick(buildingMats),x,h/2-0.5,bz); g.add(building);
          // Poucas faixas emissivas por fachada mantêm o detalhe e reduzem draw calls no celular.
          const strips=Math.max(2,Math.floor(w/1.25));
          for(let s=0;s<strips;s++) {
            const wx=x-w/2+0.55+s*(w-1.1)/Math.max(1,strips-1);
            const wm=(Math.random()>.35?windowMat:amberMat);
            g.add(box(0.12,h*0.62,0.035,wm,wx,h*0.46-0.5,bz+d/2+0.025));
          }
          g.add(box(w*0.7,0.07,0.04,windowMat,x,h*0.72-0.5,bz+d/2+0.03));
        }
        const poleX=side*7.1;
        g.add(box(0.12,3.9,0.12,railDark,poleX,1.55,-4));
        g.add(box(0.7,0.09,0.12,railMat,poleX-side*0.25,3.46,-4));
        addGlow(g,poleX-side*0.48,3.4,-4,side===1?0x53f4df:0x8b8cff,0.13);
      }
      if(i%3===1) {
        // Pórtico de estação e placas suspensas.
        g.add(box(0.23,4.6,0.23,railDark,-5.6,2.0,-2));
        g.add(box(0.23,4.6,0.23,railDark,5.6,2.0,-2));
        g.add(box(11.4,0.18,0.25,railMat,0,4.15,-2));
        const sign=box(2.8,0.55,0.12,mat(0x0b2130,0.4,0.1,{emissive:0x0b6569,emissiveIntensity:0.8}),0,3.65,-2); g.add(sign);
        addGlow(g,-0.8,3.65,-2,0x53f4df,0.06); addGlow(g,0.8,3.65,-2,0x53f4df,0.06);
      }
      segments.push(g); scene.add(g);
    }
  }

  function createPlayerRoot() {
    playerRoot = new THREE.Group(); playerRoot.position.set(0,0,0); scene.add(playerRoot);
    buildCharacter(save.equipped);
  }

  function makeLimb(parent, length, width, material, x, y, z, isLeg=false) {
    const pivot = new THREE.Group(); pivot.position.set(x,y,z); parent.add(pivot);
    const limb = box(width,length,width,material,0,-length/2,0); pivot.add(limb);
    if(isLeg) {
      const shoe = box(width*1.15,0.17,width*1.75,playerMaterials.shoe||material,0,-length+0.02,0.13); pivot.add(shoe);
    }
    return pivot;
  }

  function buildCharacter(skinId) {
    if(!playerRoot) return;
    while(playerRoot.children.length) playerRoot.remove(playerRoot.children[0]);
    playerParts={}; playerMaterials={};
    const skin=SKINS.find(s=>s.id===skinId)||SKINS[0];
    const color=new THREE.Color(skin.color), pantsColor=new THREE.Color(skin.pants), accentColor=new THREE.Color(skin.accent);
    playerMaterials.body=mat(color,0.52,skin.id==='chrome'?0.55:0.12);
    playerMaterials.pants=mat(pantsColor,0.74,0.08);
    playerMaterials.shoe=mat(skin.id==='gold'?0xffdf76:skin.accent,0.38,0.24);
    playerMaterials.skin=mat(0xc9845e,0.75,0.02);
    playerMaterials.accent=mat(accentColor,0.36,skin.id==='chrome'?0.8:0.12,{emissive:accentColor,emissiveIntensity:skin.id==='pulse'||skin.id==='volt'?0.14:0.025});
    playerMaterials.dark=mat(0x101827,0.7,0.1);
    playerMaterials.hair=mat(skin.id==='gold'?0xf4cd65:0x172033,0.9,0.01);
    const torso=box(0.68,0.76,0.39,playerMaterials.body,0,1.22,0); playerRoot.add(torso);
    const neck=new THREE.Mesh(new THREE.CylinderGeometry(0.12,0.14,0.17,10),playerMaterials.skin); neck.position.set(0,1.67,0); playerRoot.add(neck);
    const head=new THREE.Mesh(new THREE.SphereGeometry(0.29,18,14),playerMaterials.skin); head.position.set(0,1.96,0); head.castShadow=true; playerRoot.add(head);
    // Cabelo e boné/visor variam conforme a skin.
    const hair=new THREE.Mesh(new THREE.SphereGeometry(0.295,16,10,0,Math.PI*2,0,Math.PI*0.48),playerMaterials.hair); hair.position.set(0,2.04,-0.015); playerRoot.add(hair);
    const cap=box(0.62,0.13,0.47,playerMaterials.accent,0,2.19,0.015); playerRoot.add(cap);
    const brim=box(0.68,0.055,0.25,playerMaterials.accent,0,2.14,0.22); playerRoot.add(brim);
    if(skin.id==='chrome'||skin.id==='volt') {
      const visor=box(0.43,0.13,0.08,mat(skin.id==='chrome'?0x5cf3f0:0x92aaff,0.18,0.7,{emissive:skin.id==='chrome'?0x21e1e8:0x526fff,emissiveIntensity:0.8}),0,1.98,0.252); playerRoot.add(visor);
      const sideL=box(0.09,0.32,0.12,playerMaterials.accent,-0.34,1.86,0); const sideR=sideL.clone(); sideR.position.x=.34; playerRoot.add(sideL,sideR);
    } else {
      const eyeMat=new THREE.MeshBasicMaterial({color:0x142234});
      playerRoot.add(box(0.055,0.055,0.024,eyeMat,-0.10,1.99,0.263)); playerRoot.add(box(0.055,0.055,0.024,eyeMat,0.10,1.99,0.263));
    }
    // Jaqueta/peitoral com faixas próprias.
    playerRoot.add(box(0.72,0.12,0.41,playerMaterials.accent,0,1.41,0.01));
    if(skin.id==='pulse'||skin.id==='ember') {
      playerRoot.add(box(0.12,0.6,0.415,playerMaterials.accent,-0.22,1.23,0.012));
      playerRoot.add(box(0.12,0.6,0.415,playerMaterials.accent,0.22,1.23,0.012));
    } else if(skin.id==='gold') {
      playerRoot.add(box(0.44,0.22,0.43,playerMaterials.accent,0,1.22,0.02));
    } else {
      playerRoot.add(box(0.07,0.56,0.42,playerMaterials.accent,0,1.18,0.02));
    }
    playerParts.armL=makeLimb(playerRoot,0.57,0.19,playerMaterials.body,-0.47,1.5,0,false);
    playerParts.armR=makeLimb(playerRoot,0.57,0.19,playerMaterials.body,0.47,1.5,0,false);
    playerParts.legL=makeLimb(playerRoot,0.62,0.23,playerMaterials.pants,-0.21,0.79,0,true);
    playerParts.legR=makeLimb(playerRoot,0.62,0.23,playerMaterials.pants,0.21,0.79,0,true);
    // Prancha e mochila jetpack são modelos 3D de verdade, ocultos até ativar o power-up.
    boardMesh=new THREE.Group();
    const deck=box(0.72,0.10,1.12,mat(0x172339,0.28,0.45),0,0.02,-0.1); boardMesh.add(deck);
    boardMesh.add(box(0.74,0.035,0.12,playerMaterials.accent,0,0.08,-0.43)); boardMesh.add(box(0.74,0.035,0.12,playerMaterials.accent,0,0.08,0.22));
    boardMesh.position.y=0.03; boardMesh.visible=false; playerRoot.add(boardMesh); playerParts.board=boardMesh;
    jetPackMesh=new THREE.Group();
    jetPackMesh.add(box(0.43,0.52,0.22,mat(0x263a52,0.35,0.45),0,1.3,-0.29));
    jetPackMesh.add(box(0.11,0.35,0.13,playerMaterials.accent,-0.24,1.28,-0.28)); jetPackMesh.add(box(0.11,0.35,0.13,playerMaterials.accent,0.24,1.28,-0.28));
    jetPackMesh.visible=false; playerRoot.add(jetPackMesh); playerParts.jetpack=jetPackMesh;
    magnetRing=new THREE.Mesh(new THREE.TorusGeometry(0.65,0.045,8,36),new THREE.MeshBasicMaterial({color:0x53f4df,transparent:true,opacity:0.85}));
    magnetRing.position.set(0,1.45,0); magnetRing.rotation.x=Math.PI/2; magnetRing.visible=false; playerRoot.add(magnetRing); playerParts.magnet=magnetRing;
    playerRoot.position.set(LANES[laneIndex],0,0);
  }

  function setupUI() {
    $('play-btn').addEventListener('click', startGame);
    $('skins-open').addEventListener('click',()=>openScreen('skins-screen'));
    document.querySelectorAll('[data-open]').forEach(btn=>btn.addEventListener('click',()=>openScreen(`${btn.dataset.open}-screen`)));
    document.querySelectorAll('.close-screen').forEach(btn=>btn.addEventListener('click',()=>openScreen('menu-screen')));
    $('pause-btn').addEventListener('click', pauseGame);
    $('resume-btn').addEventListener('click', resumeGame);
    $('pause-restart-btn').addEventListener('click', startGame);
    $('pause-menu-btn').addEventListener('click',()=>{state='menu';clearEntities();openScreen('menu-screen');$('hud').classList.add('hidden');$('mobile-controls').classList.add('hidden');updateAllUI();});
    $('retry-btn').addEventListener('click', startGame);
    $('gameover-menu-btn').addEventListener('click',()=>{state='menu';clearEntities();openScreen('menu-screen');$('hud').classList.add('hidden');$('mobile-controls').classList.add('hidden');updateAllUI();});
    $('daily-btn').addEventListener('click', claimDaily);
    $('weather-toggle').addEventListener('click',()=>{save.settings.weather=!save.settings.weather;persist();syncSettings();toast(save.settings.weather?'Clima dinâmico ativado':'Clima dinâmico desativado');});
    $('audio-toggle').addEventListener('click',()=>{save.settings.audio=!save.settings.audio;persist();syncSettings();if(save.settings.audio) initAudio(); updateAudioGain();toast(save.settings.audio?'Áudio ativado':'Áudio desativado');});
    $('vibration-toggle').addEventListener('click',()=>{save.settings.vibration=!save.settings.vibration;persist();syncSettings();toast(save.settings.vibration?'Vibração ativada':'Vibração desativada');});
    $('volume-range').addEventListener('input',(e)=>{save.settings.volume=Number(e.target.value);persist();updateAudioGain();});
    document.querySelectorAll('[data-quality]').forEach(btn=>btn.addEventListener('click',()=>{
      save.settings.quality=btn.dataset.quality;persist();applyQuality();syncSettings();toast(save.settings.quality==='high'?'Qualidade alta selecionada':'Modo leve selecionado');
    }));
    $('mobile-controls').querySelectorAll('button').forEach(btn=>btn.addEventListener('pointerdown',(e)=>{e.preventDefault();if(state==='running')action(btn.dataset.action);}));
    window.addEventListener('keydown',(e)=>{
      const key=e.key.toLowerCase();
      if(['arrowleft','arrowright','arrowup','arrowdown',' '].includes(key)) e.preventDefault();
      if((key==='escape'||key==='p')&&state==='running'){pauseGame();return;}
      if(key==='escape'&&state==='paused'){resumeGame();return;}
      if(state!=='running') { if((key==='enter'||key===' ')&&state==='menu'&&activeScreen==='menu-screen') startGame(); return; }
      if(key==='arrowleft'||key==='a')action('left');
      else if(key==='arrowright'||key==='d')action('right');
      else if(key==='arrowup'||key==='w'||key===' ')action('jump');
      else if(key==='arrowdown'||key==='s')action('slide');
    });
    let touchStart=null;
    canvas.addEventListener('touchstart',(e)=>{if(!e.touches.length)return;touchStart={x:e.touches[0].clientX,y:e.touches[0].clientY};},{passive:true});
    canvas.addEventListener('touchend',(e)=>{
      if(!touchStart||state!=='running'){touchStart=null;return;}
      const t=e.changedTouches[0],dx=t.clientX-touchStart.x,dy=t.clientY-touchStart.y;
      if(Math.max(Math.abs(dx),Math.abs(dy))>25){if(Math.abs(dx)>Math.abs(dy))action(dx>0?'right':'left');else action(dy<0?'jump':'slide');}
      touchStart=null;
    },{passive:true});
    canvas.addEventListener('contextmenu',e=>e.preventDefault());
    syncSettings(); renderSkins(); renderShop(); renderMissions();
  }

  function openScreen(id) {
    document.querySelectorAll('.screen').forEach(el=>el.classList.remove('active'));
    $(id).classList.add('active'); activeScreen=id;
    if(id==='skins-screen') { renderSkins(); $('skin-preview-label').textContent='VISUALIZANDO: '+(SKINS.find(s=>s.id===save.equipped)||SKINS[0]).name.toUpperCase(); }
    if(id==='shop-screen') renderShop();
    if(id==='missions-screen') renderMissions();
    if(id==='settings-screen') syncSettings();
    $('hud').classList.toggle('hidden',state!=='running');
    $('mobile-controls').classList.toggle('hidden',state!=='running'||window.innerWidth>720);
  }

  function action(type) {
    if(state!=='running') return;
    if(type==='left') laneIndex=Math.max(0,laneIndex-1);
    else if(type==='right') laneIndex=Math.min(2,laneIndex+1);
    else if(type==='jump') {
      if(jumpY<=0.015 && slideTimer<=0.02 && activePowers.jetpack<=0) {
        jumpVelocity=activePowers.shoes>0?13.5+save.upgrades.shoes*1.2:10.7+save.upgrades.shoes*1.15;
        playTone(320,0.09,'triangle',0.07); vibrate(10);
      }
    } else if(type==='slide') {
      if(jumpY<0.7){slideTimer=0.76;playTone(190,0.07,'sawtooth',0.035);}
    }
  }

  function startGame() {
    unlockAudio();
    clearEntities();
    state='running'; laneIndex=1;laneX=0;jumpY=0;jumpVelocity=0;slideTimer=0;runDistance=0;score=0;runCoins=0;
    spawnTimer=0.25;powerTimer=6;elapsed=0;cameraShake=0;newRecord=false;hoverShieldUsed=false;
    activePowers={magnet:0,shoes:0,jetpack:0,hoverboard:0,multiplier:0};
    playerRoot.position.set(0,0,0); playerRoot.rotation.set(0,0,0);
    boardMesh.visible=false;jetPackMesh.visible=false;magnetRing.visible=false;
    // reposiciona os módulos de cenário para evitar saltos ao reiniciar.
    segments.forEach((g,i)=>g.position.z=-i*SEGMENT_LENGTH);
    $('hud').classList.remove('hidden');$('mobile-controls').classList.toggle('hidden',window.innerWidth>720);
    document.querySelectorAll('.screen').forEach(el=>el.classList.remove('active'));activeScreen='';
    $('power-status').innerHTML=''; updateHUD(true); updateAllUI();
    if(save.settings.audio) startMusic();
  }
  function pauseGame() {
    if(state!=='running')return; state='paused';
    $('hud').classList.add('hidden');$('mobile-controls').classList.add('hidden');
    document.querySelectorAll('.screen').forEach(el=>el.classList.remove('active'));$('pause-screen').classList.add('active');activeScreen='pause-screen';
  }
  function resumeGame(){if(state!=='paused')return;state='running';$('pause-screen').classList.remove('active');activeScreen='';$('hud').classList.remove('hidden');$('mobile-controls').classList.toggle('hidden',window.innerWidth>720);if(save.settings.audio)startMusic();}

  function endGame() {
    if(state!=='running')return;
    state='gameover';
    const previous=save.best;
    save.best=Math.max(save.best,score);newRecord=score>previous;
    save.stats.distance+=Math.floor(runDistance);save.stats.bestRun=Math.max(save.stats.bestRun,score);save.stats.runs+=1;
    persist();updateAllUI();
    $('final-score').textContent=score.toLocaleString('pt-BR')+' m';$('final-coins').textContent=runCoins.toLocaleString('pt-BR');$('final-best').textContent=save.best.toLocaleString('pt-BR')+' m';
    $('new-record').classList.toggle('hidden',!newRecord);
    $('hud').classList.add('hidden');$('mobile-controls').classList.add('hidden');
    document.querySelectorAll('.screen').forEach(el=>el.classList.remove('active'));$('gameover-screen').classList.add('active');activeScreen='gameover-screen';
    stopMusic();playTone(95,.32,'sawtooth',.06);vibrate([45,35,45]);
  }

  function createTrain() {
    const g=new THREE.Group();
    const bodyMat=mat(0x253c57,.35,.42), frontMat=mat(0x17283f,.32,.4), glassMat=new THREE.MeshStandardMaterial({color:0x5de5ea,metalness:.25,roughness:.18,emissive:0x0b6978,emissiveIntensity:.65});
    g.add(box(1.78,2.55,7.6,bodyMat,0,1.28,0));
    g.add(box(1.62,.48,0.18,frontMat,0,2.58,3.82));
    g.add(box(1.66,.24,.11,glassMat,0,2.23,3.88));
    g.add(box(1.65,.08,7.3,mat(0x46d6d8,.3,.3,{emissive:0x168f9a,emissiveIntensity:.3}),0,.2,0));
    for(let side of [-1,1]) {
      for(let i=0;i<4;i++) g.add(box(.07,.62,.08,glassMat,side*.91,1.7,-2.4+i*1.55));
      g.add(box(.09,.10,7.5,mat(0xffd26b,.4,.1,{emissive:0xf59e39,emissiveIntensity:.65}),side*.91,.72,0));
    }
    return g;
  }
  function createObstacle(type) {
    if(type==='train')return createTrain();
    const g=new THREE.Group();
    if(type==='barrier') {
      const orange=mat(0xff763d,.65,.03), white=mat(0xffead6,.65,.02), dark=mat(0x263347,.7,.1);
      g.add(box(1.56,.72,.55,orange,0,.42,0));
      for(let i=-1;i<=1;i++)g.add(box(.28,.75,.57,white,i*.48,.42,.015));
      g.add(box(1.75,.13,.68,dark,0,.04,0));
      g.add(box(.10,.7,.10,dark,-.55,-.12,-.08));g.add(box(.10,.7,.10,dark,.55,-.12,-.08));
    } else if(type==='overhead') {
      const frame=mat(0x394c64,.5,.35), danger=mat(0xff4f9a,.35,.2,{emissive:0x8a1645,emissiveIntensity:.3});
      g.add(box(1.8,.17,.22,frame,0,2.0,0));g.add(box(.12,1.8,.18,frame,-.78,1.13,0));g.add(box(.12,1.8,.18,frame,.78,1.13,0));
      g.add(box(1.5,.13,.25,danger,0,1.82,0.03));
    } else if(type==='sign') {
      const steel=mat(0x34485f,.4,.5), sign=mat(0x182c43,.45,.25,{emissive:0x174e65,emissiveIntensity:.4});
      g.add(box(.13,1.65,.13,steel,0,.8,0));g.add(box(1.3,.55,.14,sign,0,1.72,0));
      g.add(box(.08,.28,.03,mat(0x57f3dc,.25,.05,{emissive:0x53f4df,emissiveIntensity:.8}),0,1.72,.09));
    }
    return g;
  }
  function addEntity(type,lane,z,extra={}) {
    let group;
    if(type==='coin') {
      group=new THREE.Group();
      const coinMat=mat(0xffd467,.23,.68,{emissive:0xb77518,emissiveIntensity:.35});
      const coin=new THREE.Mesh(new THREE.TorusGeometry(.28,.095,9,18),coinMat); coin.rotation.y=Math.PI/2; group.add(coin);
      group.add(new THREE.Mesh(new THREE.TorusGeometry(.11,.026,6,12),new THREE.MeshBasicMaterial({color:0xfff1ab})));
      group.position.y=1.12;
    } else if(['magnet','shoes','jetpack','hoverboard','multiplier'].includes(type)) {
      group=new THREE.Group();
      const cols={magnet:0x53f4df,shoes:0xffd36e,jetpack:0xff6b9e,hoverboard:0x67a6ff,multiplier:0xc58aff};
      const col=cols[type];
      group.add(new THREE.Mesh(new THREE.OctahedronGeometry(.36,1),new THREE.MeshStandardMaterial({color:col,emissive:col,emissiveIntensity:.75,metalness:.3,roughness:.25})));
      const ring=new THREE.Mesh(new THREE.TorusGeometry(.52,.035,7,28),new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:.82}));ring.rotation.x=Math.PI/2;group.add(ring);
      group.add(new THREE.Mesh(new THREE.SphereGeometry(.12,10,8),new THREE.MeshBasicMaterial({color:0xffffff})));
      group.position.y=1.25;
    } else group=createObstacle(type);
    const x=LANES[lane];group.position.x=x;group.position.z=z;scene.add(group);
    const entity={type,lane,z,x,group,resolved:false,passed:false,halfDepth:type==='train'?3.8:0.42,...extra};entities.push(entity);return entity;
  }
  function spawnPattern() {
    const z=-66;
    const lane=Math.floor(Math.random()*3);
    const roll=Math.random();
    const type=roll<.25?'train':roll<.62?'barrier':roll<.84?'overhead':'sign';
    addEntity(type,lane,z);
    // Fileiras de moedas em uma faixa segura, além de pequenas variações verticais.
    let safeLanes=[0,1,2].filter(l=>l!==lane);let coinLane=pick(safeLanes);
    for(let i=0;i<6;i++) addEntity('coin',coinLane,z-5-i*1.75,{coinValue:1});
    if(Math.random()<.42) {
      const other=[0,1,2].filter(l=>l!==lane&&l!==coinLane);
      addEntity('coin',pick(other),z-8,{coinValue:1});addEntity('coin',pick(other),z-10,{coinValue:1});
    }
  }
  function spawnPowerup() {
    const types=['magnet','shoes','jetpack','hoverboard','multiplier'];
    const type=pick(types), lane=Math.floor(Math.random()*3);
    addEntity(type,lane,-67);
  }
  function clearEntities() {
    for(const e of entities)scene.remove(e.group);
    entities=[];
    for(const p of particles)scene.remove(p.mesh);
    particles=[];
  }

  function collectCoin(entity) {
    entity.resolved=true;scene.remove(entity.group);runCoins++;save.coins++;save.stats.coins++;persist();
    makeBurst(entity.group.position.x,entity.group.position.y,entity.group.position.z,0xffd467,7);
    if(runCoins%5===0)playTone(950,.06,'sine',.06);else playTone(740+Math.random()*150,.045,'sine',.04);
    updateHUD(false); if(runCoins%10===0)toast('+'+runCoins+' moedas nesta corrida!');
  }
  function activatePower(type, x=LANES[laneIndex], z=-1) {
    const u=save.upgrades;
    if(type==='magnet')activePowers.magnet=8+u.magnet*2;
    if(type==='shoes')activePowers.shoes=8+u.shoes*1.5;
    if(type==='jetpack'){activePowers.jetpack=5; jumpY=Math.max(jumpY,3.8);jumpVelocity=0;}
    if(type==='hoverboard'){activePowers.hoverboard=10+u.board*2;hoverShieldUsed=false;}
    if(type==='multiplier')activePowers.multiplier=8+u.multiplier*1.5;
    save.stats.powers++;persist();playTone(520,.12,'triangle',.075);setTimeout(()=>playTone(820,.13,'sine',.06),65);vibrate(20);
    toast(({magnet:'ÍMÃ DE MOEDAS ATIVADO',shoes:'SUPER TÊNIS ATIVADOS',jetpack:'JETPACK ATIVADO',hoverboard:'HOVERBOARD ATIVADO',multiplier:'MULTIPLICADOR X2 ATIVADO'})[type]||'POWER-UP!');
    const colors={magnet:0x53f4df,shoes:0xffd36e,jetpack:0xff6b9e,hoverboard:0x67a6ff,multiplier:0xc58aff};
    makeBurst(x,1.25,z,colors[type]||0x53f4df,13);
  }
  function makeBurst(x,y,z,color,count=10) {
    const material=new THREE.MeshBasicMaterial({color,transparent:true,opacity:1});
    for(let i=0;i<count;i++) {
      const mesh=new THREE.Mesh(new THREE.SphereGeometry(rand(.025,.07),6,5),material.clone());
      mesh.position.set(x,y,z);scene.add(mesh);
      particles.push({mesh,life:rand(.25,.65),maxLife:.65,vel:new THREE.Vector3(rand(-2,2),rand(.4,3),rand(-1.5,1.5))});
    }
  }

  function updateGame(dt) {
    const speed=Math.min(29,16+runDistance*.0072);
    runDistance+=speed*dt;
    score=Math.floor(runDistance*(activePowers.multiplier>0?2:1));
    laneX+=(LANES[laneIndex]-laneX)*Math.min(1,dt*13);
    if(activePowers.jetpack>0){activePowers.jetpack=Math.max(0,activePowers.jetpack-dt);jumpY=3.9+Math.sin(elapsed*7)*.13;} else {
      if(jumpY>0||jumpVelocity>0){jumpY+=jumpVelocity*dt;jumpVelocity-=28*dt;if(jumpY<=0){jumpY=0;jumpVelocity=0;}}
    }
    slideTimer=Math.max(0,slideTimer-dt);
    for(const k of Object.keys(activePowers))activePowers[k]=Math.max(0,activePowers[k]-dt);
    boardMesh.visible=activePowers.hoverboard>0;jetPackMesh.visible=activePowers.jetpack>0;magnetRing.visible=activePowers.magnet>0;
    if(magnetRing.visible){magnetRing.rotation.z+=dt*2.2;magnetRing.scale.setScalar(1+Math.sin(elapsed*8)*.05);}
    playerRoot.position.x=laneX;playerRoot.position.y=jumpY;playerRoot.rotation.z+=( (LANES[laneIndex]-laneX)*-.045-playerRoot.rotation.z)*Math.min(1,dt*8);
    // Animação de corrida; ao deslizar, o corredor se agacha.
    const runSwing=Math.sin(elapsed*(8+speed*.16));
    playerParts.armL.rotation.x=runSwing*.85;playerParts.armR.rotation.x=-runSwing*.85;
    playerParts.legL.rotation.x=-runSwing*.72;playerParts.legR.rotation.x=runSwing*.72;
    if(slideTimer>0&&jumpY<.1){playerRoot.scale.y=.58;playerRoot.position.y=-.03;}else playerRoot.scale.y=1;
    if(activePowers.jetpack>0){playerRoot.rotation.x=Math.sin(elapsed*8)*.035;}else playerRoot.rotation.x=0;

    for(const seg of segments){seg.position.z+=speed*dt;if(seg.position.z>SEGMENT_LENGTH)seg.position.z-=SEGMENT_LENGTH*SEGMENT_COUNT;}
    spawnTimer-=dt;if(spawnTimer<=0){spawnPattern();spawnTimer=Math.max(.68,1.13-(speed-16)*.018);}
    powerTimer-=dt;if(powerTimer<=0){spawnPowerup();powerTimer=rand(9,14);}

    // Ímã atrai moedas próximas mesmo em outra faixa.
    for(const e of entities) {
      if(e.resolved)continue;
      e.z+=speed*dt;
      if(e.type==='coin') {
        e.group.rotation.y+=dt*3.5;e.group.position.y=1.12+Math.sin(elapsed*4+e.z)*.08;
        if(activePowers.magnet>0&&Math.abs(e.z)<13) {
          e.x+=(laneX-e.x)*Math.min(1,dt*4.8);e.group.position.x=e.x;
        }
      } else if(['magnet','shoes','jetpack','hoverboard','multiplier'].includes(e.type)) {
        e.group.rotation.y+=dt*1.8;e.group.position.y=1.25+Math.sin(elapsed*3+e.z)*.13;
      }
      e.group.position.z=e.z;
      const dz=e.z;
      if(e.type==='coin') {
        if(Math.abs(dz)<1.15 && (Math.abs(e.x-laneX)<.95 || activePowers.magnet>0)) collectCoin(e);
        else if(activePowers.magnet>0 && Math.abs(dz)<2.7 && Math.abs(e.x-laneX)<1.1) collectCoin(e);
      } else if(['magnet','shoes','jetpack','hoverboard','multiplier'].includes(e.type)) {
        if(Math.abs(dz)<1.15&&Math.abs(e.x-laneX)<1.0){e.resolved=true;scene.remove(e.group);activatePower(e.type,e.x,e.z);}
      } else {
        const inCollisionZone=dz>(-e.halfDepth-.45)&&dz<.8;
        if(!e.resolved&&inCollisionZone&&Math.abs(e.x-laneX)<1.05) {
          if(e.type==='barrier'&&jumpY>1.12) { e.resolved=true;makeBurst(e.x,.6,e.z,0x53f4df,5); }
          else if(e.type==='overhead'&&slideTimer>0) { e.resolved=true;makeBurst(e.x,1.7,e.z,0x53f4df,5); }
          else if(activePowers.jetpack>0) { e.resolved=true; }
          else if(activePowers.hoverboard>0&&!hoverShieldUsed) { e.resolved=true;hoverShieldUsed=true;activePowers.hoverboard=0;boardMesh.visible=false;cameraShake=.38;makeBurst(e.x,1,e.z,0x67a6ff,18);playTone(130,.18,'square',.08);toast('HOVERBOARD BLOQUEOU A BATIDA!');vibrate([25,20,25]); }
          else {e.resolved=true;cameraShake=.6;makeBurst(e.x,1,e.z,0xff4f9a,15);endGame();break;}
        }
      }
      if(!e.passed&&e.z>2){e.passed=true;if(['barrier','train','overhead','sign'].includes(e.type)&&!e.resolved){/* obstáculos ultrapassados são descartados */}}
    }
    // Remoção de objetos já coletados ou que ficaram para trás.
    entities=entities.filter(e=>{if(e.resolved||e.z>16){scene.remove(e.group);return false;}return true;});
    updateParticles(dt);
    if(save.settings.weather)updateWeather(dt);
    if(cameraShake>0)cameraShake=Math.max(0,cameraShake-dt);
    updateCamera(dt); updateHUD(false); updatePowerStatus();
  }

  function updateWeather(dt) {
    // Troca suave de matiz entre azul noturno, violeta e teal conforme a distância.
    const cycle=(runDistance%1800)/1800;
    const colors=[new THREE.Color(0x0b1930),new THREE.Color(0x231b3f),new THREE.Color(0x092a35)];
    let a,b,t;
    if(cycle<.5){a=colors[0];b=colors[1];t=cycle*2;}else{a=colors[1];b=colors[2];t=(cycle-.5)*2;}
    scene.background.copy(a).lerp(b,t);scene.fog.color.copy(scene.background);
    scene.fog.density=.0095+Math.sin(cycle*Math.PI*2)*.001;
  }
  function updateParticles(dt) {
    particles=particles.filter(p=>{p.life-=dt;if(p.life<=0){scene.remove(p.mesh);return false;}p.mesh.position.addScaledVector(p.vel,dt);p.vel.y-=4*dt;p.mesh.material.opacity=Math.max(0,p.life/p.maxLife);return true;});
  }
  function updateCamera(dt) {
    const menuMode=(state==='menu'&&activeScreen!=='')||state==='gameover';
    const offset=menuMode?-2.0:0;
    const targetX=laneX*.25+offset;
    const shakeX=cameraShake>0?rand(-cameraShake,cameraShake)*.22:0;
    const desired=new THREE.Vector3(targetX,4.25+(jumpY*.16)+(cameraShake>0?rand(0,cameraShake)*.4:0),10.2);
    camera.position.lerp(desired,Math.min(1,dt*3.5));
    camera.lookAt(targetX*.38,1.15+jumpY*.22,-8.2);
    if(state==='running') {
      const fov=64+Math.min(5,(runDistance/900));camera.fov+=(fov-camera.fov)*dt*1.6;camera.updateProjectionMatrix();
    } else {camera.fov+=(64-camera.fov)*dt*1.5;camera.updateProjectionMatrix();}
    camera.position.x+=shakeX;
    if(activeScreen==='skins-screen'&&state==='menu')playerRoot.rotation.y=Math.sin(elapsed*.65)*.3+Math.PI*.05;
    else if(state!=='running')playerRoot.rotation.y=Math.sin(elapsed*.5)*.08;
  }

  function animate() {
    const dt=Math.min(clock.getDelta(),.045);
    elapsed+=dt;
    if(state==='running') updateGame(dt);
    else {
      // Cenário ainda vivo no menu, com pequenos movimentos de luz e personagem.
      playerParts.armL.rotation.x=Math.sin(performance.now()*.0017)*.10;
      playerParts.armR.rotation.x=-playerParts.armL.rotation.x;
      if(save.settings.weather&&state==='menu') {const shift=Math.sin(performance.now()*.0001)*.015;scene.fog.density=.010+shift;}
      updateCamera(dt);
      if(state==='menu') {for(const seg of segments){/* cenário fica no lugar no menu */}}
    }
    renderer.render(scene,camera);
  }

  function onResize() {
    camera.aspect=window.innerWidth/window.innerHeight;camera.updateProjectionMatrix();
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,save.settings.quality==='high'?1.65:1.15));
    renderer.setSize(window.innerWidth,window.innerHeight,false);
    $('mobile-controls').classList.toggle('hidden',state!=='running'||window.innerWidth>720);
  }
  function applyQuality() {
    renderer.setPixelRatio(Math.min(window.devicePixelRatio||1,save.settings.quality==='high'?1.65:1.15));
    renderer.shadowMap.enabled=save.settings.quality==='high';
    renderer.setSize(window.innerWidth,window.innerHeight,false);
  }

  function updateHUD(force) {
    if(force||score!==lastHudScore){$('score-value').textContent=score.toLocaleString('pt-BR');lastHudScore=score;}
    if(force||runCoins!==lastHudCoins){$('run-coins').textContent=runCoins.toLocaleString('pt-BR');lastHudCoins=runCoins;}
  }
  function updatePowerStatus() {
    const labels={magnet:'🧲 ÍMÃ',shoes:'👟 SUPER TÊNIS',jetpack:'🚀 JETPACK',hoverboard:'🛹 HOVERBOARD',multiplier:'✦ SCORE X2'};
    $('power-status').innerHTML=Object.entries(activePowers).filter(([,t])=>t>0).map(([k,t])=>`<span class="power-pill">${labels[k]} · ${t.toFixed(0)}s</span>`).join('');
  }
  function updateAllUI() {
    $('menu-coins').textContent=save.coins.toLocaleString('pt-BR');$('shop-coins').textContent=save.coins.toLocaleString('pt-BR');
    $('menu-best').textContent=save.best.toLocaleString('pt-BR')+' m';$('menu-level').textContent=String(1+Math.floor(save.stats.distance/1000)).padStart(2,'0');
    renderSkinsIfVisible();
  }
  function renderSkinsIfVisible(){if($('skins-screen').classList.contains('active'))renderSkins();}
  function renderSkins() {
    const grid=$('skins-grid');if(!grid)return;
    grid.innerHTML=SKINS.map(s=>{
      const unlocked=save.unlocked.includes(s.id),selected=save.equipped===s.id;
      const action=selected?'EQUIPADA':unlocked?'EQUIPAR':`DESBLOQUEAR · ${s.price} 🟡`;
      return `<article class="skin-card ${selected?'selected':''}" style="--skin-color:${s.color};--skin-color-alpha:${s.color}20"><div class="skin-avatar">${s.icon}</div><h3>${s.name}</h3><p>${s.desc}</p><div class="skin-price">${unlocked?s.title:`🟡 ${s.price} MOEDAS`}</div><button class="skin-action" data-skin="${s.id}" ${selected?'disabled':''}>${action}</button></article>`;
    }).join('');
    grid.querySelectorAll('[data-skin]').forEach(btn=>btn.addEventListener('click',()=>{
      const skin=SKINS.find(s=>s.id===btn.dataset.skin);if(!skin)return;
      if(!save.unlocked.includes(skin.id)){
        if(save.coins<skin.price){toast('Moedas insuficientes para desbloquear esta skin.');return;}
        save.coins-=skin.price;save.unlocked.push(skin.id);toast(skin.name+' desbloqueada!');
      }
      save.equipped=skin.id;buildCharacter(skin.id);persist();updateAllUI();renderSkins();$('skin-preview-label').textContent='VISUALIZANDO: '+skin.name.toUpperCase();
    }));
  }
  function renderShop() {
    $('shop-coins').textContent=save.coins.toLocaleString('pt-BR');
    $('shop-grid').innerHTML=SHOP_ITEMS.map(item=>{
      const level=save.upgrades[item.id]||0, price=Math.round(item.price*(1+level*.65));
      return `<article class="shop-card"><div class="shop-icon">${item.icon}</div><h3>${item.name}</h3><p>${item.desc}</p><div class="shop-meta"><strong>NÍVEL ${level}/${item.max}</strong><button data-upgrade="${item.id}" ${level>=item.max?'disabled':''}>${level>=item.max?'MÁXIMO':`🟡 ${price}`}</button></div></article>`;
    }).join('');
    $('shop-grid').querySelectorAll('[data-upgrade]').forEach(btn=>btn.addEventListener('click',()=>{
      const item=SHOP_ITEMS.find(i=>i.id===btn.dataset.upgrade),level=save.upgrades[item.id]||0,price=Math.round(item.price*(1+level*.65));
      if(level>=item.max)return;if(save.coins<price){toast('Você precisa de mais moedas.');return;}
      save.coins-=price;save.upgrades[item.id]=level+1;persist();renderShop();updateAllUI();toast(item.name+' melhorado para nível '+(level+1));playTone(650,.11,'triangle',.06);
    }));
    const claimedToday=save.lastDaily===new Date().toLocaleDateString('en-CA');
    $('daily-btn').disabled=claimedToday;$('daily-btn').textContent=claimedToday?'JÁ RESGATADO':'RESGATAR +250';
    $('daily-btn').classList.toggle('btn-glass',claimedToday);$('daily-btn').classList.toggle('btn-primary',!claimedToday);
  }
  function claimDaily() {
    const today=new Date().toLocaleDateString('en-CA');
    if(save.lastDaily===today){toast('A recompensa diária já foi resgatada hoje.');return;}
    save.lastDaily=today;save.coins+=250;persist();renderShop();updateAllUI();toast('Bônus diário: +250 moedas!');playTone(660,.14,'sine',.07);
  }
  function missionProgress(m) {
    if(m.metric==='coins')return save.stats.coins;
    if(m.metric==='distance')return save.stats.distance;
    if(m.metric==='powers')return save.stats.powers;
    if(m.metric==='bestRun')return save.stats.bestRun;
    return 0;
  }
  function renderMissions() {
    $('missions-list').innerHTML=MISSIONS.map(m=>{
      const p=Math.min(m.target,missionProgress(m)),done=p>=m.target,claimed=save.claimed.includes(m.id),pct=Math.round(p/m.target*100);
      return `<article class="mission-card"><div class="mission-icon">${m.icon}</div><div><h3>${m.title}</h3><p>${m.desc}</p><div class="progress-track"><span style="width:${pct}%"></span></div></div><div><div class="mission-amount">+${m.reward} 🟡</div><button class="mission-claim" data-claim="${m.id}" ${!done||claimed?'disabled':''}>${claimed?'RESGATADA':done?'RESGATAR':' '+p.toLocaleString('pt-BR')+' / '+m.target.toLocaleString('pt-BR')}</button></div></article>`;
    }).join('');
    $('missions-list').querySelectorAll('[data-claim]').forEach(btn=>btn.addEventListener('click',()=>{
      const m=MISSIONS.find(i=>i.id===btn.dataset.claim);if(!m||save.claimed.includes(m.id)||missionProgress(m)<m.target)return;
      save.claimed.push(m.id);save.coins+=m.reward;persist();renderMissions();updateAllUI();toast('Missão concluída: +'+m.reward+' moedas!');playTone(780,.15,'triangle',.07);
    }));
  }
  function syncSettings() {
    document.querySelectorAll('[data-quality]').forEach(b=>b.classList.toggle('selected',b.dataset.quality===save.settings.quality));
    $('weather-toggle').classList.toggle('on',save.settings.weather);$('audio-toggle').classList.toggle('on',save.settings.audio);$('vibration-toggle').classList.toggle('on',save.settings.vibration);
    $('volume-range').value=save.settings.volume;
  }
  function toast(message) {
    const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2400);
  }
  function vibrate(pattern) {if(save.settings.vibration&&navigator.vibrate){try{navigator.vibrate(pattern);}catch{}}}

  // Áudio procedural: efeitos e pequenas notas sem arquivos externos.
  function initAudio() {
    if(audioCtx)return;
    try {const AudioContext=window.AudioContext||window.webkitAudioContext;if(!AudioContext)return;audioCtx=new AudioContext();masterGain=audioCtx.createGain();masterGain.gain.value=(save.settings.audio?save.settings.volume/100:0)*.3;masterGain.connect(audioCtx.destination);}catch{}
  }
  function unlockAudio(){if(!save.settings.audio)return;initAudio();if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume();startMusic();}
  function updateAudioGain(){if(masterGain)masterGain.gain.setTargetAtTime((save.settings.audio?save.settings.volume/100:0)*.3,audioCtx.currentTime,.06);if(!save.settings.audio)stopMusic();else if(state==='running')startMusic();}
  function playTone(freq,duration=.08,wave='sine',volume=.05) {
    if(!save.settings.audio)return;initAudio();if(!audioCtx||!masterGain)return;
    try {if(audioCtx.state==='suspended')audioCtx.resume();const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type=wave;osc.frequency.setValueAtTime(freq,audioCtx.currentTime);osc.frequency.exponentialRampToValueAtTime(Math.max(45,freq*.72),audioCtx.currentTime+duration);gain.gain.setValueAtTime(volume,audioCtx.currentTime);gain.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);osc.connect(gain);gain.connect(masterGain);osc.start();osc.stop(audioCtx.currentTime+duration+.02);}catch{}
  }
  function startMusic(){if(!save.settings.audio||state!=='running'||musicTimer)return;initAudio();if(!audioCtx)return;if(audioCtx.state==='suspended')audioCtx.resume();const notes=[220,277,330,277,196,247,294,247];musicTimer=setInterval(()=>{if(state!=='running'||!save.settings.audio)return;playTone(notes[musicStep%notes.length],.16,'triangle',.018);if(musicStep%4===0)playTone(82,.12,'sine',.026);musicStep++;},230);}
  function stopMusic(){if(musicTimer){clearInterval(musicTimer);musicTimer=null;}}
}
